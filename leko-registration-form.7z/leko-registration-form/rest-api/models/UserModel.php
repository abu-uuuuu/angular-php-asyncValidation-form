<?php

usingClass('classes.validators.ValidatorCollection');
usingClass('classes.validators.EmailValidator');
usingClass('classes.validators.CallbackValidator');
usingClass('classes.validators.StringValidator');
usingClass('classes.validators.RussianLettersValidator');

/**
 * Модель для работы с пользователями из БД
 *
 * @author Bujinov Andrei
 */
class UserModel extends GenericModel{
    private $id;
    private $nickName;
    private $firstName;
    private $lastName;
    private $email;
    private $password;

    function __construct($id, $nickName, $firstName, $lastName, $email, $password) {
        $this->id = $id;
        $this->nickName = $nickName;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->email = $email;
        $this->password = $password;
    }

    function getId() {
        return $this->id;
    }

    function getNickName() {
        return $this->nickName;
    }

    function getFirstName() {
        return $this->firstName;
    }

    function getLastName() {
        return $this->lastName;
    }

    function getEmail() {
        return $this->email;
    }

    function getPassword() {
        return $this->password;
    }

    /**
     * Возвращает пользователя из БД по никнейму (не используется)
     */
    public static function findByNickName($nickName){
        $sql = 'select `id`, `nickName`, `firstName`, `lastName`, `email`, `password` from `users` where `nickName` = :nickName';
        $stmt = self::getDbAdapter()->execute($sql, ['nickName' => $nickName]);
        
        while($row = $stmt->fetch())
        {
            return new self(
                $row['id'],
                $row['nickName'],
                $row['firstName'],
                $row['lastName'],
                $row['email'],
                $row['password']
            );
        }

        return null;
    }
    /**
     * Проверяет уникальность пользователя по никнейму
     * @param string $nickName
     * @return boolean
     */
    public static function isUniqueNickName($nickName){
        $sql = 'select `id` from `users` where `nick_name` = :nickName';
        $stmt = self::getDbAdapter()->execute($sql, ['nickName' => $nickName]);
        return $stmt->rowCount() == 0;
    }
    /**
     * Проверяет уникальность пользователя по email
     * @param string $email
     * @return boolean
     */
    public static function isUniqueEmail($email){
        $sql = 'select `id` from `users` where `email` = :email';
        $stmt = self::getDbAdapter()->execute($sql, ['email' => $email]);        
        return $stmt->rowCount() == 0;
    }
    /**
     * Валидация никнейма
     * @param string $nickName
     * @return boolean | string
     */
    public static function isValidNickName($nickName){
        $validators = new GroupValidators();

        $v = new StringValidator($nickName, 3, 150);
        $v->setMinLengthMessage('Длина никнейма не может быть меньше чем %MIN%.');
        $v->setMaxLengthMessage('Длина никнейма не может быть больше чем %MAX%.');
        $validators->AddValidator($v, 'nickName');
        
        $v = new CallbackValidator($nickName, array('UserModel', 'isUniqueNickName'));
        $v->setNotValidMessage('Пользователь с указанным никнеймом уже зарегистрирован.');
        $validators->AddValidator($v, 'nickName');

        $v = new RegexValidator($nickName, "/^[a-zA-Z][a-zA-Z\d]*$/i");
        $v->setRegexMessage('Никнейм должен содержать только латинские буквы и цифры, и начинаться с латинской буквы.');
        $validators->AddValidator($v, 'nickName');
        
        if(!$validators->Validate()){
            return $validators->GetErrors();
        }
        
        return true;
    }
    /**
     * Валидация имени
     * @param type $firstName
     * @return boolean | string
     */
    public static function isValidFirstName($firstName){
        $validators = new GroupValidators();
        
        $v = new StringValidator($firstName, 2, 150);
        $v->setMinLengthMessage('Длина имени не может быть меньше чем %MIN%.');
        $v->setMaxLengthMessage('Длина имени не может быть больше чем %MAX%.');
        $validators->AddValidator($v, 'firstName');

        $v = new RussianLettersValidator($firstName);
        $v->setMessage('Допустимы только русские буквы.');
        $validators->AddValidator($v, 'firstName');
        
        if(!$validators->Validate()){
            return $validators->GetErrors();
        }
        
        return true;
    }
    /**
     * Валидация фамилии
     * @param type $lastName
     * @return boolean | string
     */
    public static function isValidLastName($lastName){
        $validators = new GroupValidators();
        
        $v = new StringValidator($lastName, 2, 150);
        $v->setMinLengthMessage('Длина фамилии не может быть меньше чем %MIN%.');
        $v->setMaxLengthMessage('Длина фамилии не может быть больше чем %MAX%.');
        $validators->AddValidator($v, 'lastName');

        $v = new RussianLettersValidator($lastName);
        $v->setMessage('Допустимы только русские буквы.');
        $validators->AddValidator($v, 'lastName');        
        
        if(!$validators->Validate()){
            return $validators->GetErrors();
        }
        
        return true;
    }
    /**
     * Валидация email
     * @param type $email
     * @return boolean | string
     */
    public static function isValidEmail($email){
        $validators = new GroupValidators();
        
        $v = new EmailValidator($email);
        $v->setEmailMessage('Неправильный формат e-mail адреса.');
        $validators->AddValidator($v, 'email');

        $v = new CallbackValidator($email, array('UserModel', 'isUniqueEmail'));
        $v->setNotValidMessage('Пользователь с указанным e-mail уже существует.');
        $validators->AddValidator($v, 'email');
        
        if(!$validators->Validate()){
            return $validators->GetErrors();
        }
        
        return true;
    }
    /**
     * Валидация пароля
     * @param type $password
     * @return boolean | string
     */
    public static function isValidPassword($password){
        $validators = new GroupValidators();
        
        $v = new StringValidator($password, 5, 150);
        $v->setMinLengthMessage('Длина пароля не может быть меньше чем %MIN%.');
        $v->setMaxLengthMessage('Длина пароля не может быть больше чем %MAX%.');
        $validators->AddValidator($v, 'password');

        if(!$validators->Validate()){
            return $validators->GetErrors();
        }
        
        return true;
    }

    /**
     * Сохраняет пользователя в БД
     */
    public static function persist($nickName, $firstName, $lastName, $email, $password){
        $sql = 'insert into `users` set `nick_name` = :nickName, `first_name` = :firstName, `last_name` = :lastName, `email` = :email, `password` = :password';
        $parameters = [
            'nickName' => $nickName,
            'firstName' => $firstName,
            'lastName' => $lastName,
            'email' => $email,
            'password' => md5($password),
        ];
        return self::getDbAdapter()->execute($sql, $parameters)->rowCount() == 1 ? true : false;
    }
}