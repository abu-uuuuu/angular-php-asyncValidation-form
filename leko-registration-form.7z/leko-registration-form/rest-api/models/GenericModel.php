<?php
/**
 * АрхиМодель
 *
 * @author Bujinov Andrei
 */
class GenericModel {
    /**
     * @return DbAdapter
     */
    static function getDbAdapter() {
        return DbAdapter::getInstance();
    }
}