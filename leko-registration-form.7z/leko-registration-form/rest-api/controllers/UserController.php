<?php
/**
 * Контроллер для работы с пользователями
 *
 * @author Bujinov Andrei
 */
class UserController extends GenericController{
    const ERROR_MSG_COULD_NOT_PERSIST = "Не удалось сохранить пользователя";
    
    /**
     * Сохраняет в базе нового пользователя, перед сохранением запускает валидацию 
     * для всех параметров. Если какая-то валидация не прошла, список ошибок отправляется
     * на клиента без сохранения.
     */
    public function actionPutPersist() {
        $requestParameters = self::getRequest()->getParameters();
        
        //валидация параметров
        $validationErrors = [];
        foreach($requestParameters as $key => $value){
            $isValid = $this->validateUserField($key, $value);
            
            if($isValid !== true){
                $validationErrors += $isValid;
            }
        }
        //если есть ошибки валидации, отправляем их клиенту (без сохранения)
        if(count($validationErrors) > 0){
            $this->renderStatusError($validationErrors);
        }
        //собственно сохранение
        if(UserModel::persist(
            $requestParameters['nickName'],
            $requestParameters['firstName'],
            $requestParameters['lastName'],
            $requestParameters['email'],
            $requestParameters['password']
        ))
        {
            $this->renderStatusSuccess();
        }else{
            $this->renderStatusError(self::ERROR_MSG_COULD_NOT_PERSIST);
        }
    }
    /**
     * Обёртка для валидации конкретного поля
     */
    public function actionGetValidate(){
        $requestParameters = self::getRequest()->getParameters();
        foreach($requestParameters as $key => $value){
            $isValid = $this->validateUserField($key, $value);
            
            if($isValid === true){
                $this->renderStatusSuccess();
            }else{
                $this->renderStatusError($isValid);
            }
        }
    }    
    /**
     * Валидация для конкретного поля
     */
    private function validateUserField($key, $value){
        $fieldMap = [
            "email" => "isValidEmail",
            "nickName" => "isValidNickName",
            "lastName" => "isValidLastName",
            "firstName" => "isValidFirstName",
            "password" => "isValidPassword",
        ];
        
        if(!array_key_exists($key, $fieldMap)){
            $this->renderStatusError("Не определна ф-ция валидации");
        }
        
        return UserModel::$fieldMap[$key]($value);
    }
}