<?php
define('LIBRARIES_PATH', dirname(__FILE__));
ini_set('include_path', ini_get('include_path') . ':' . LIBRARIES_PATH . ':');

/**
* Loads a class from libraries of the namespace.
* @param string - The namespace of the class.
* @access public
* @return bool
*/
function usingClass($namespace)
{
    static $sLoaded;

    if (!is_array($sLoaded) || !in_array($namespace, $sLoaded))
    {
        $path = LIBRARIES_PATH . '/' . str_replace('.', '/', $namespace) . '.class.php';

        if (file_exists($path))
        {
            require_once($path);
            $sLoaded[] = $namespace;
        }
        else
            return false;
    }

    return true;
}