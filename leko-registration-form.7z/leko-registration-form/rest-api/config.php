<?php
return [
    'db'=>[
        'connectionString' => 'mysql:host=localhost;dbname=leko',
        'username' => 'leko',
        'password' => 'leko',
        'charset' => 'utf8',
    ],
];