<?php
/**
 * АрхиГенератор выдачи
 *
 * @author Bujinov Andrei
 */
abstract class GenericView {
    abstract protected function render($content);    
    public function renderStatusSuccess() {
        header('Content-Type: application/json; charset=utf8');
        die(json_encode(["status"=>"OK"]));
    }
    public function renderStatusError($msg) {
        header('Content-Type: application/json; charset=utf8');
        die(json_encode(["status"=>"ERROR","message"=>$msg]));
    }
}