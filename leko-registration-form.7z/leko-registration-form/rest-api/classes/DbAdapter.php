<?php
/**
 * Обёртка для работы с базой данных
 *
 * @author Bujinov Andrei
 */
class DbAdapter {
    private static $instance;
    
    private $pdo;
    
    private function __construct() {
        $config = require(dirname(__FILE__).DIRECTORY_SEPARATOR.'..'.DIRECTORY_SEPARATOR.'config.php');
        $configDb = $config['db'];
        $dsn = $configDb['connectionString'];
        $opt = array(
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        );
        $username = $configDb['username'];
        $password = $configDb['password'];

        $this->pdo = new PDO($dsn, $username, $password, $opt);        
    }
    
    public static function getInstance(){
        if(!isset(self::$instance))self::$instance = new self();
        return self::$instance;
    }
    
    public function execute($sql, $parameters = null){
        if($parameters !== null){
            $stmt = $this->pdo->prepare($sql);
            $stmt->execute($parameters);
        }else 
        {
            $stmt = $this->pdo->query($sql);
        }
        
        return $stmt;
    }
}