<?php
/**
 * Структура для выдачи пользователей
 *
 * @author Bujinov Andrei
 */
class UserDao {
    public $id;
    public $nickName;
    public $firstName;
    public $lastName;
    public $email;
    public $password;
    
    function __construct($id, $nickName, $firstName, $lastName, $email, $password) {
        $this->id = $id;
        $this->nickName = $nickName;
        $this->firstName = $firstName;
        $this->lastName = $lastName;
        $this->email = $email;
        $this->password = $password;
    }

    public static function cast(UserModel $userModel){
        return new self(
            $userModel->getId(),
            $userModel->getNickName(),
            $userModel->getFirstName(),
            $userModel->getLastName(),
            $userModel->getEmail(),
            $userModel->getPassword()
        );
    }
}