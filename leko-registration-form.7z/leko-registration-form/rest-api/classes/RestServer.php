<?php
/**
 * Сервер, подключает автозагрузку классов, 
 * выбирает по запросу контроллер и вызывает нужный action
 *
 * @author Bujinov Andrei
 */
class RestServer {
    function __construct() {
        spl_autoload_register(
            function($classname)
            {
                if (preg_match('/Controller$/', $classname)) {
                    include __DIR__ . '/../controllers/' . $classname . '.php';
                } elseif (preg_match('/Model$/', $classname)) {
                    include __DIR__ . '/../models/' . $classname . '.php';
                } elseif (preg_match('/View$/', $classname)) {
                    include __DIR__ . '/../views/' . $classname . '.php';
                } else {
                    include __DIR__ . '/../classes/' . $classname . '.php';
                }
                return true;
            }
        );        
    }

    public function handle(){
        $request = Request::getInstance();
        $request->dispatch();
        $urlParts = $request->getUrlParts();
                
        //TODO check count($urlParts)
        $controllerName = ucfirst($urlParts[2])."Controller";
        $action = "action".ucfirst(strtolower($request->getVerb())).ucfirst(strtolower($urlParts[3]));
        $actionParameter = @$urlParts[4];
        
        //TODO check file_exists
        $controller = new $controllerName;
        //TODO check action exists, better using call_user_func
        $controller->$action($actionParameter);
    }
}
