<?php
usingClass('classes.validators.exceptions.ArgumentException');

abstract class BaseValidator
{
    private $_value;
    private $_errorMsg;

    public function __construct(&$value)
    {
        $this->_value = $value;
        $this->_errorMsg = null;
    }

/* --- Methods --- */

    /**
    * Determines whether the value is valid.
    * @return bool
    */
    abstract function Validate();
    /**
    * Gets a error text
    * @return string
    */
    public function Equals(BaseValidator &$obj)
    {
        return $this == $obj;
    }

/* --- Properties --- */

    public function getErrorMessage()
    {
        return $this->_errorMsg;
    }
    /**
    * Sets a error text
    * @param string
    */
    protected function setErrorMessage($msg)
    {
        if (is_string($msg))
            $this->_errorMsg = $msg;
        else
            throw new ArgumentException('Wrong type of argument', '$msg');
    }
    protected function &getValue()
    {
        return $this->_value;
    }
}