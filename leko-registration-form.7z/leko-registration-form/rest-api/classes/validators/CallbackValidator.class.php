<?php
usingClass('classes.validators.BaseValidator');

class CallbackValidator extends BaseValidator
{
    private $_callbackDelegate;
    private $_errorMessage;

    /**
    * Initializes an instance of the StringValidator class
    * @param string [ref] - the string value for validate
    * @param callback - the callback delegate for validate ( bool delegate($value) )
    * @return StringValidator
    */
    public function __construct(&$value, $callback)
    {
        if (!is_string($callback) && (!is_array($callback) || 2 != count($callback)))
            throw new ArgumentException('Wrong type of argument', '$callback');

        parent::__construct($value);

        $this->_callbackDelegate = $callback;
        $this->_errorMessage = 'The value is not valid';
    }
    /**
    * Determines whether the string value is valid.
    * @return bool
    */
    public function Validate()
    {
        $isValid = (bool)call_user_func($this->_callbackDelegate, $this->getValue());

        if ($isValid)
            return true;

        $this->setErrorMessage($this->_errorMessage);
        return false;
    }
    /**
    * Sets a message of error
    * @param string - the error message
    */
    public function setNotValidMessage($message)
    {
        if (!is_string($message))
            throw new ArgumentException('Wrong type of argument', '$message');

        $this->_errorMessage = $message;
    }
}