<?php
usingClass('classes.validators.BaseValidator');

class RegexValidator extends BaseValidator
{
    private $_regex;
    private $_regexMessage;

    /**
    * Initializes an instance of the StringValidator class
    * @param string [ref] - the string value for validate
    * @param string - a string that specifies a regular expression.
    * @return RegexValidator
    */
    public function __construct(&$value, $regex)
    {
        if (!is_string($value))
            throw new ArgumentException('Wrong type of argument', '$value');

        if (!is_string($regex))
            throw new ArgumentException('Wrong type of argument', '$regex');

        parent::__construct($value);

        $this->_regex = $regex;
        $this->_regexMessage = 'The value is not valid for pattern';
    }
    /**
    * Determines whether the string value is valid.
    * @return bool
    */
    public function Validate()
    {
        if (preg_match($this->_regex, $this->getValue()))
            return true;

        $this->setErrorMessage($this->_regexMessage);

        return false;
    }
    /**
    * Sets a message for regex error
    * @param string - the error message
    */
    public function setRegexMessage($message)
    {
        if (!is_string($message))
            throw new ArgumentException('Wrong type of argument', '$message');

        $this->_regexMessage = $message;
    }
}