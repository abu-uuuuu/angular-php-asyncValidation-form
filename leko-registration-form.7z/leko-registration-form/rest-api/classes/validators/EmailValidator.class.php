<?php
usingClass('classes.validators.RegexValidator');

class EmailValidator extends RegexValidator
{
    /**
    * Initializes an instance of the EmailValidator class
    * @param string [ref] - the string value for validate
    * @param bool [optional] - the TRUE if contain seconds in the value; otherwise, FALSE.
    * @return TimeStringValidator
    */
    public function __construct(&$value)
    {
        if (!is_string($value))
            throw new ArgumentException('Wrong type of argument', '$value');

        parent::__construct($value, "/^[a-z0-9\._%\+\-]+@[a-z0-9\-\.]+\.[a-z]{2,6}$/i");

        $this->setRegexMessage('The email is not valid');
    }
    /**
    * Sets a message for email error
    * @param string - the error message
    */
    public function setEmailMessage($message)
    {
        $this->setRegexMessage($message);
    }
}