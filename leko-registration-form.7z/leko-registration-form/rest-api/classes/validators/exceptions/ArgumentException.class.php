<?php
class ArgumentException extends Exception
{
    private $_paramName;

    public function __construct($message='Wrong type of argument', $paramName='')
    {
        parent::__construct($message);

        $this->_paramName = $paramName;
    }

    public function getParamName()
    {
        return $this->_paramName;
    }
}