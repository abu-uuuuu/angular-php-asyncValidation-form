<?php
usingClass('classes.validators.BaseValidator');

class GroupValidators
{
    protected $_groups;
    protected $_errors;

    /**
    * Initalize a new instance of the GroupValidators class.
    */
    public function __construct()
    {
        $this->_groups = array();
        $this->_errors = array();
    }

/* --- Methods --- */

    /**
    * Add a specified validator to a specified validation group
    * @param BaseValidator - the validator to add.
    * @param string [optional] - the name of validation group
    */
    public function AddValidator(BaseValidator $validator, $groupName='default')
    {
        if (!is_string($groupName))
            throw new ArgumentException('Wrong type of argument.', '$groupName');

        $groupName = trim($groupName);
        if (empty($groupName))
            throw new AppendIterator('The name of group is invalid.', '$groupName');

        if (!isset($this->_groups[$groupName]))
        {
            $this->_groups[$groupName] = new ValidatorCollection(true);
        }

        $this->_groups[$groupName]->Add($validator);
    }
    /**
    * Returns a collection of validators for a specified validation group
    * @param string [optional] - the name of group
    * @return ValidatorCollection
    */
    public function GetValidators($groupName='default')
    {
        if (!is_string($groupName))
            throw new ArgumentException('Wrong type of argument.', '$groupName');

        if (isset($this->_groups[$groupName]))
            return $this->_groups[$groupName];

        return null;
    }
    /**
    * @return bool
    */
    public function Validate()
    {
        /**
        * @var BaseValidator
        */
        $validator = null;
        $isSuccess = true;

        foreach ($this->_groups as $gName => $validators)
        {
            $this->_errors[$gName] = null;

            foreach ($validators as $validator)
            {
                if (!$validator->Validate())
                {
                    $this->_errors[$gName] = $validator->getErrorMessage();
                    $isSuccess = false;
                    break;
                }
            }
        }

        return $isSuccess;
    }
    /**
    * Gets errors list of validation groups
    * @return array
    */
    public function GetErrors()
    {
        return $this->_errors;
    }
    /**
    * Gets a error of specified validation group
    * @param string - the validation group name
    * @return string
    */
    public function GetErrorOfGroup($validationGroup)
    {
        if (!is_string($validationGroup))
            throw new ArgumentException('Wrong type of argument.', '$validationGroup');

        if (isset($this->_errors[$validationGroup]))
            return $this->_errors[$validationGroup];

        return null;
    }
}

class ValidatorCollection implements Iterator, Countable
{
    protected $_items;
    protected $_unique;

    /**
    * Initialize a new instance of the ValidatorCollection class
    * @param bool [optional] - the TRUE for unique items in the collection; otherwise, false
    * @return ValidatorCollection
    */
    public function __construct($unique=false)
    {
        $this->_items = array();
        $this->_unique = (bool)$unique;
    }

/* --- Methods --- */

    /**
    * Adds the specified validator to this collection.
    * @param BaseValidator - the validator to add
    */
    public function Add(BaseValidator $validator)
    {
        if ($this->_unique && $this->Contains($validator))
            return;

        $this->_items[] = $validator;
    }
    /**
    * Determines whether an element is in the collection
    * Returns TRUE if $validator is found in the collection; otherwise, false
    * @param BaseValidator - the validator to locate in the collection
    * @return bool
    */
    public function Contains(BaseValidator $validator)
    {
        if (is_object($validator))
        {
            foreach ($this->_items as $item)
                if ($item->Equals($validator))
                    return true;
        }
        return false;
    }
    /**
    * Inherited of IteratorAggregate interface
    * @return ValidatorCollection
    */
    public function getIterator()
    {
        return $this;
    }
    /**
    * Inherited of Countable interface
    * @return int
    */
    public function count()
    {
        return count($this->_items);
    }
    /**
    * Inherited of Iterator interface
    * @return BaseValidator
    */
    public function current()
    {
        return current($this->_items);
    }
    /**
    * Inherited of Iterator interface
    * @return int
    */
    public function key()
    {
        return key($this->_items);
    }
    /**
    * Inherited of Iterator interface
    * @return BaseValidator
    */
    public function next()
    {
        return next($this->_items);
    }
    /**
    * Inherited of Iterator interface
    */
    public function rewind()
    {
        reset($this->_items);
    }
    /**
    * Inherited of Iterator interface
    * @return bool
    */
    public function valid()
    {
        return $this->current() !== false;
    }
}