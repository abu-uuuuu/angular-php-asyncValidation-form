<?php
usingClass('classes.validators.RegexValidator');

class RussianLettersValidator extends RegexValidator
{
    /**
    * Initializes an instance of the RussianLettersValidator class
    * @param string [ref] - the string value for validate
    * @param bool [optional] - the TRUE if contain seconds in the value; otherwise, FALSE.
    * @return RussianLettersValidator
    */
    public function __construct(&$value)
    {
        if (!is_string($value))
            throw new ArgumentException('Wrong type of argument', '$value');

        parent::__construct($value, "/^[А-Яа-я]*$/u");

        $this->setRegexMessage('String should contain only russian letters');
    }
    /**
    * Sets a message for email error
    * @param string - the error message
    */
    public function setMessage($message)
    {
        $this->setRegexMessage($message);
    }
}