<?php
usingClass('classes.validators.BaseValidator');

class StringValidator extends BaseValidator
{
    private $_minLength;
    private $_maxLength;
    private $_invalidChars;
    private $_minLengthMessage;
    private $_maxLengthMessage;
    private $_invalidCharsMessage;

    /**
    * Initializes an instance of the StringValidator class
    * @param string [ref] - the string value for validate
    * @param int [optional] - the minimum length of the string value
    * @param int [optional] - the maximum length of the string value
    * @param string [optional] - a string that represents invalid characters.
    * @return StringValidator
    */
    public function __construct(&$value, $minLength=1, $maxLength=null, $invalidCharatcers=null)
    {
        if (!is_string($value))
            throw new ArgumentException('Wrong type of argument', '$value');

        if (!is_numeric($minLength))
            throw new ArgumentException('Wrong type of argument', '$minLength');

        if (!is_null($maxLength))
        {
            if (!is_numeric($maxLength))
                throw new ArgumentException('Wrong type of argument', '$maxLength');
            else if ($minLength >= $maxLength)
                throw new ArgumentException('MinLength is greater than MaxLength');
        }

        if (!is_null($invalidCharatcers) && !is_string($invalidCharatcers))
            throw new ArgumentException('Wrong type of argument', '$invalidCharacters');

        parent::__construct($value);

        $this->_minLength = (int)$minLength;
        $this->_maxLength = (is_null($maxLength)) ? null : (int)$maxLength;
        $this->_invalidChars = (is_null($invalidCharatcers)) ? null : $invalidCharatcers;
        $this->_minLengthMessage = 'The value is less than %MIN%';
        $this->_maxLengthMessage = 'The value is greater than %MAX%';
        $this->_invalidCharsMessage = 'The value contains invalid characters';
    }
    /**
    * Determines whether the string value is valid.
    * @return bool
    */
    public function Validate()
    {
        if (mb_strlen($this->getValue(), 'UTF-8') < $this->_minLength)
        {
            $this->setErrorMessage(str_replace('%MIN%', $this->_minLength, $this->_minLengthMessage));
        }
        else if (!is_null($this->_maxLength) && mb_strlen($this->getValue(), 'UTF-8') > $this->_maxLength)
        {
            $this->setErrorMessage(str_replace('%MAX%', $this->_maxLength, $this->_maxLengthMessage));
        }
        else if (!is_null($this->_invalidChars) && preg_match("/" . preg_quote($this->_invalidChars, "/") . "/", $this->getValue()))
        {
            $this->setErrorMessage($this->_invalidCharsMessage);
        }
        else
        {
            return true;
        }

        return false;
    }
    /**
    * Sets a message for min value error
    * Allowed replacement text - %MIN%
    * @param string - the error message
    */
    public function setMinLengthMessage($message)
    {
        if (!is_string($message))
            throw new ArgumentException('Wrong type of argument', '$message');

        $this->_minLengthMessage = $message;
    }
    /**
    * Sets a message for max value error
    * Allowed replacement text - %MAX%
    * @param string - the error message
    */
    public function setMaxLengthMessage($message)
    {
        if (!is_string($message))
            throw new ArgumentException('Wrong type of argument', '$message');

        $this->_maxLengthMessage = $message;
    }
    /**
    * Sets a message for invalid characters
    * @param string - the error message
    */
    public function setInvalidCharactersMessage($message)
    {
        if (!is_string($message))
            throw new ArgumentException('Wrong type of argument', '$message');

        $this->_invalidCharsMessage = $message;
    }
}