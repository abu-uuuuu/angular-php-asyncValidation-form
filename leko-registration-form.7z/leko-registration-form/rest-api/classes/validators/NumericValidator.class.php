<?php
usingClass('classes.validators.BaseValidator');

class NumericValidator extends BaseValidator
{
    private $_minValue;
    private $_maxValue;
    private $_outOfRangeMessage;

    public function __construct(&$value, $minValue, $maxValue)
    {
        if (!is_numeric($value))
            throw new ArgumentException('Wrong type of argument', '$value');

        if (!is_numeric($minValue))
            throw new ArgumentException('Wrong type of argument', '$minValue');

        if (!is_numeric($maxValue))
            throw new ArgumentException('Wrong type of argument', '$maxValue');

        if ($minValue >= $maxValue)
            throw new ArgumentException('MinValue is greater than MaxValue');

        parent::__construct($value);

        $this->_minValue = $minValue;
        $this->_maxValue = $maxValue;

        $this->_outOfRangeMessage = 'The value must not be less than %MIN% and greater than %MAX%.';
    }

    public function Validate()
    {
        if ($this->getValue() >= $this->_minValue && $this->getValue() <= $this->_maxValue)
            return true;

        $this->setErrorMessage(str_replace(
            array('%MIN%', '%MAX%'),
            array($this->_minValue, $this->_maxValue),
            $this->_outOfRangeMessage));
        return false;
    }

    /**
    * Sets a message of validate error
    * Allowed replacement text - %MIN%, %MAX%
    * @param string - the error message
    */
    public function setOutOfRangeMessage($message)
    {
        if (!is_string($message))
            throw new ArgumentException('Wrong type of argument', '$message');

        $this->_outOfRangeMessage = $message;
    }
}