(function () {
    'use strict';

    angular.module("LekoApp")
        .factory("usersService", ["$http", "$q", "CONFIG", function ($http, $q, CONFIG) {
            var host_url = CONFIG.host + CONFIG.url_service;
            var http_cache = CONFIG.http_cache;

            return {
                
                validateField: function(params, fieldName, callback) {
                    if (!params) {
                        return;
                    }

                    var deferred = $q.defer();

                    $http({
                        url: host_url + 'user/validate',
                        method: "GET",
                        cache: http_cache,
                        params: params
                    })
                    .then(
                        function(response){
                            if(response.data.status === 'OK'){
                                callback(fieldName, null);
                                deferred.resolve();
                            }else{
                                callback(fieldName, response.data.message[fieldName]);
                                deferred.reject();
                            }
                        },
                        function(response){deferred.reject(response);}
                    );

                    return deferred.promise;
                },

                createUser: function(data) {
                    if (!data) {
                        return;
                    }

                    var deferred = $q.defer();

                    $http({
                        url: host_url + 'user/persist',
                        method: "PUT",
                        cache: http_cache,
                        data: data,
                        headers: {
                            "Content-Type": "application/json"
                        }
                    })
                    .then(
                        function(response){
                            if(response.data.status === 'OK'){
                                deferred.resolve();
                            }else{
                                deferred.reject(response.data);
                            }
                        },
                        function(response){deferred.reject(response);}
                    );

                    return deferred.promise;
                }
            };
        }]);
})();