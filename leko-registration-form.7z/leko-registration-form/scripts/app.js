'use strict';

angular.module('LekoApp',['ngRoute'])

.constant('CONFIG', {
    host: "",
    url_service: "/rest-api/",
    http_cache: false
})

.config(function($routeProvider) {
    $routeProvider
        .when('/users', {
            templateUrl: 'views/users.html',
            controller: 'UsersController'
        })
        .otherwise({
            redirectTo: '/users'
        });        
})

.controller('MainController', ['$scope', function($scope) {
}]);