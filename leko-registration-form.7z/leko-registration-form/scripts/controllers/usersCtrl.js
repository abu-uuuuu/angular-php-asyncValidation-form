(function () {
    'use strict';

    angular.module("LekoApp")
        .controller("UsersController", ["$scope", "usersService", function($scope, usersService) {
            $scope.registrationFormIsSubmitted = false;
            $scope.user = {};
            
            $scope.validationMap = {
                nickName: function(modelValue, viewValue){
                    return $scope.validationMap.validate('nickName', modelValue || viewValue);
                },
                firstName: function(modelValue, viewValue){
                    return $scope.validationMap.validate('firstName', modelValue || viewValue);
                },
                lastName: function(modelValue, viewValue){
                    return $scope.validationMap.validate('lastName', modelValue || viewValue);
                },
                email: function(modelValue, viewValue){
                    return $scope.validationMap.validate('email', modelValue || viewValue);
                },
                password: function(modelValue, viewValue){
                    return $scope.validationMap.validate('password', modelValue || viewValue);
                },
                setErrorMessage: function(fieldName, message){
                    $scope.validationErrorMesages = $scope.validationErrorMesages || {};
                    $scope.validationErrorMesages[fieldName] = message;
                },
                validate: function(fieldName, value){
                    var params = {};
                    
                    params[fieldName] = value;

                    return usersService.validateField(params, fieldName, $scope.validationMap.setErrorMessage);
                }
            };

            $scope.createUser = function(){
                usersService.createUser($scope.user)
                .then(
                    function(){
                        $scope.validationErrorMesages.backendMessages = null;
                        $scope.registrationFormIsSubmitted = true;
                    },
                    function(reason){
                        if(reason.message){
                            $scope.validationErrorMesages.backendMessages = reason.message;
                        }else{
                            console.error(reason);
                            alert("Ошибка! Проверьте сообщения в консоли.");
                        }
                    }
                );
            };
        }]);
})();