'use strict';

angular.module('LekoApp')
    .directive('backendValidation', function () {
        return{
            require:'ngModel',
            link:function($scope,element,attrs,ngModel){
                ngModel.$asyncValidators.backendValidation = $scope.validationMap[attrs.name];
            }
        }      
    }
);